# Kink in the armor

## Arsenal 

Since Arsenal's historic Invincible season, Arsene Wenger's team has undeniably dissapointed their legions of fans. Analyzing the league form since the 2004-2005 check, one finds that Arsenal has scored on average only around 3 less goals per season. However, on average, Manchester United has finished about 12 points ahead of Arsenal on a per season basis. Indeed, United has finished as Premier League champion 4 of the 8 seasons since that amazing season in 2003-2004. 

<table border="1.0" align="center" cellpadding="0" cellspacing="0">
<tr bgcolor="gray">
<td>         Team         </td><td>  Goals For  </td><td>  Goals Against  </td>
<td> Points </td>
</tr>
<tr>
<td>  Arsenal </td><td>          589          </td><td>     303      </td>
<td> 586 </td>
</tr>
<tr>
<td>  Man United </td><td>  614  </td><td>     231      </td>
<td> 680 </td>
</tr>
</table>

# How can this be?

Clearly, this might point to defensive failings rather than offensive ones. However, Arsenal received just 8 more goals against per season in this span than Manchester United. How can this translate to such a large difference in fortunes? A closer look at the distribution of the number of goals conceded per game reveals Arsenal is simply far less efficient in winning matches given their offensive output. If one assigns a sort of efficiency to each goal scored in terms of generated points, one has that Manchester United's every goal produces about 1.10 points. Arsenal on the other hand obtains about 0.99 points per goal.





 
