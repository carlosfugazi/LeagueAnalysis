 # Who is Ars Futbolistica?

## Skills

"I have are a very particular set of skills; skills I have acquired over a very long career (*graduated 2 years ago*). Skills that make me a nightmare for people like you (*mainly if you are a lazy football pundit*)."

The applied mathematician is a strange beast, a creature of two worlds. The first is one in which coffee is converted to rigorous (*pure*) mathematical proof as Erdos observed (*he of the Erdos #*). Problem is, the results are intelligible to at around two people, the guy who wrote it and his editor that has to read it. Secondarily, there is the world of applied mathematics, where the practitioner must navigate the imperfections whatever data is extracted from real world experiments, and approximate models of how the world behaves. Think fluid motion or the bounce of a inflated football.

# Transition

This author really likes to watch that football bounce. Preferably on the ground. Stoke City dig here. Regardless, 

