# “Never compete with someone who has nothing to lose.”

Baltasar Gracián uttered the titular words of this post. I am not sure if Old Baltasar figured out the converse of his statement, that maybe "one should compete with someone who has nothing to gain". This seems to be increasingly the case in the English Premier League.

![](http://media.tumblr.com/dbc36c21c3cecde91f771b0a377d2734/tumblr_inline_mjzwh8fyf01qz4rgp.png)

| -------------------- | -------------------- | -------------------- |
| Team                 | Finishes in top 4    | Years achieved       |
| -------------------- | -------------------- | -------------------- |
| Arsenal              |          16          |                      |
| Manchester United    |          16          |                      |
| Chelsea              |          11          |                      |
| Liverpool            |          10          |                      |
| Newcastle United     |          3           |  1997, 2002, 2003    |
| Leeds United         |          3           |  1999, 2000, 2001    |
| Manchester City      |          2           |  2011, 2012          |
| Tottenham Hotspur    |          2           |  2010, 2012          |
| Everton              |          1           |  2005                |
| -------------------- | -------------------- | -------------------- |


Total number of leagues:  16
Trend slope = 2.19 pts/year
Trend slope = 0.49 pts/year
Trend slope = -0.47 pts/year
Trend slope = -0.63 pts/year
Trend slope = -0.97 pts/year




